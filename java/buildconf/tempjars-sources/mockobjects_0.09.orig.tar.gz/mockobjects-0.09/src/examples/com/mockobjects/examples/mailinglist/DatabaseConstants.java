package com.mockobjects.examples.mailinglist;

public interface DatabaseConstants {
    public final static int UNIQUE_CONSTRAINT_VIOLATED = 1;

}
