package com.mockobjects.atg;
import atg.repository.*;/**
 * Creation date: (06/04/2001 09:58:14)
 * @author:
 */
public class MockQuery implements Query {

    /**
     * MockQuery constructor comment.
     */
    public MockQuery() {
        super();
    }

    /**
     * getQueryOperation method comment.
     */
    public String getQueryOperation() {
        return null;
    }

    /**
     * getQueryRepresentation method comment.
     */
    public String getQueryRepresentation() {
        return null;
    }
}