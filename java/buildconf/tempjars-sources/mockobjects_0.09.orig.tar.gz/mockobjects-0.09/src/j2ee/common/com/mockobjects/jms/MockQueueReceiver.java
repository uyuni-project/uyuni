package com.mockobjects.jms;

import com.mockobjects.*;
import javax.jms.*;

public class MockQueueReceiver extends MockMessageConsumer implements QueueReceiver {

  public Queue getQueue() {
    notImplemented();
    return null;
  }
}