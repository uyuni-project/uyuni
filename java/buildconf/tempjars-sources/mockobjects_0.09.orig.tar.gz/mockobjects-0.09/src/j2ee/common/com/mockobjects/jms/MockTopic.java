package com.mockobjects.jms;

import com.mockobjects.*;
import javax.jms.*;

public class MockTopic extends MockObject implements Topic{

    public String getTopicName() throws JMSException{
        notImplemented();
        return null;
    }

}
