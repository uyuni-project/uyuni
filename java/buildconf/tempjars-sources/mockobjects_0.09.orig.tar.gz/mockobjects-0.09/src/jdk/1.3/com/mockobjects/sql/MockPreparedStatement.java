package com.mockobjects.sql;

public class MockPreparedStatement extends CommonMockPreparedStatement {
}
