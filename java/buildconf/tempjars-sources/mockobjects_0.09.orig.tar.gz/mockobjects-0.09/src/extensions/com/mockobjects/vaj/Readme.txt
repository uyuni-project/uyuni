One version of mock implementation of the VisualAge IDE library.
Not sure which one to use yet.
