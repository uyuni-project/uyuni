package com.mockobjects.sql;

/**
 * @deprecated Use temporary class MockConnection2
 * @see MockConnection2
 * @version $Revision: 1.3 $
 */
public class MockConnection extends CommonMockConnection{
}
