package com.mockobjects.sql;

public class MockMultiRowResultSet extends CommonMockMultiRowResultSet{
    public MockMultiRowResultSet() {
    }

    public MockMultiRowResultSet(String name) {
        super(name);
    }
}
