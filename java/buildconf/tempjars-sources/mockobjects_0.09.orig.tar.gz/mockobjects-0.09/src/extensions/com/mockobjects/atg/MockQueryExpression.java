package com.mockobjects.atg;
import atg.repository.*;/**
 * Creation date: (06/04/2001 09:58:43)
 * @author:
 */
public class MockQueryExpression implements QueryExpression {

    /**
     * MockQueryExpression constructor comment.
     */
    public MockQueryExpression() {
        super();
    }

    /**
     * getQueryOperation method comment.
     */
    public String getQueryOperation() {
        return null;
    }

    /**
     * getQueryRepresentation method comment.
     */
    public String getQueryRepresentation() {
        return null;
    }
}