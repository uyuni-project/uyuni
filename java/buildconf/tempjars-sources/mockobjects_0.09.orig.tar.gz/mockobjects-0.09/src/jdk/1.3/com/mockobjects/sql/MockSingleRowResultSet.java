package com.mockobjects.sql;

public class MockSingleRowResultSet extends CommonMockSingleRowResultSet {
}
