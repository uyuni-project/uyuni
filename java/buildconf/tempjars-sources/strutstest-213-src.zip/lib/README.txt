Please note that you will need the following
libraries to run this build:

Cactus:
------
aspectjrt.jar
cactus.jar
httpclient.jar

Commons Packages:
----------------
commons-beanutils.jar
commons-collections.jar
commons-digester.jar
commons-logging.jar

XML Packages:
------------
crimson.jar
jaxp.jar

JUnit:
-----
junit.jar

Servlet API:
-----------
servlet.jar

Struts:
------
struts.jar
tiles.jar
