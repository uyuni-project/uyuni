package com.mockobjects.sql;


public class MockStatement extends CommonMockStatement {
}
